import java.util.ArrayList;
import java.util.*;
import java.util.List;

public class ContactList {
    Scanner s = new Scanner(System.in);
    List<Contact> contacts = new ArrayList<>();
    public ContactList(){}
    int i=0;
    int k=1;

    public void Add(Contact contact){
        contacts.add(contact);

    }
    public void Display(){
        System.out.println("\n\tFirst Name\t Last Name \t\t Phone number");
        for(Contact con: contacts){
            System.out.println("\t"+con.firstName+"\t\t\t"+con.lastName+"\t\t"+con.telephone.phone_number);
            k++;
        }
        System.out.println();
    }
    public void Update(){
        System.out.print("Enter phone number for update: ");
        int number =s.nextInt();
        for (Contact con : contacts){
            if(number==con.telephone.phone_number){
                System.out.print("Enter new first name: ");
                String newFname= s.next();
                System.out.print("Enter new last name: ");
                String newLname = s.next();
                System.out.print("Enter new phone numer: ");
                int newPnumber = s.nextInt();
                con.setFirstname(newFname);
                con.setLastName(newLname);
                con.setTelephone(newPnumber);
                i=1;

            }
        }
        if(i==0){
            System.out.println("\nThis phone number not match\n");
        }
    }
    public void Delete(){
        System.out.print("Enter phone number for delete: ");
        int number =s.nextInt();
        Iterator<Contact> itr = contacts.iterator();
        while (itr.hasNext()){
            Contact con = itr.next();
            if(number==con.telephone.phone_number){
                itr.remove();
                i=1;
            }
        }
        if(i==0){
            System.out.println("\nThis phone number not match\n");
        }
    }


}
