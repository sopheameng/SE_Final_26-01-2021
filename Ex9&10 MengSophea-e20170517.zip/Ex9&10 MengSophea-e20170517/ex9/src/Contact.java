

public class Contact {
    Telephone telephone = new Telephone();
    public String firstName;
    public String lastName;
    public Contact(String firstName, String lastName,int phone_number){
        this.firstName=firstName;
        this.lastName=lastName;
        this.telephone.phone_number = phone_number;
    }



    public void setFirstname(String firstName){
            this.firstName =firstName;
    }
    public void setLastName(String lastName){
        this.lastName=lastName;
    }
    public void setTelephone(int phone_number){
        this.telephone.phone_number=phone_number;
    }

}
