import java.util.*;
public class Menu {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
ContactList contactList = new ContactList();
        int option=0;
        while (option!=5){
            System.out.println("1. Add ");
            System.out.println("2. Update");
            System.out.println("3. Delete");
            System.out.println("4. Listing");
            System.out.println("5. Quit");
            System.out.print("Choose any option: ");
            option=s.nextInt();
            switch (option){
                case 1:
                    System.out.print("Enter first name: ");
                    String fname = s.next();

                    System.out.print("Enter last name: ");
                    String lname = s.next();
                    System.out.print("Enter phone number: ");
                    int number= s.nextInt();
                    Contact contact = new Contact(fname,lname,number);


                    contactList.Add(contact);
                    break;
                case 2: contactList.Update();
                break;
                case 3: contactList.Delete();
                break;
                case 4: contactList.Display();
                break;
                default: System.out.println("Invalid choice!! choose again");
            }
        }
    }
}
