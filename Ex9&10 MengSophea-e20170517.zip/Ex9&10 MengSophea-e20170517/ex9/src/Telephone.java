public class Telephone {
    public int phone_number;

        public  Telephone(){}
}
